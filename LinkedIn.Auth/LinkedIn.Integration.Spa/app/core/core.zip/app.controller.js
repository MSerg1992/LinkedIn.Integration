﻿App.controller('RootCtrl', [RootController]);

function RootController() {
    var vm = this;
}