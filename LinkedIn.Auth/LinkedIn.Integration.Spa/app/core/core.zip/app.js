﻿var App = angular.module('LinkedIn.SPA', [
    'LocalStorageModule',
    'ui.router'
]);