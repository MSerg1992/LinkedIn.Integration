﻿App.config(AppConfig);

function AppConfig($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/welcome');

    $stateProvider
        .state('welcome', {
            url: '/welcome',
            templateUrl: 'app/states/welcome/welcome.html',
            data: {
                requireLogin: false
            }
        })
        .state('app', {
            abstract: true,
            data: {
                requireLogin: true // this property will apply to all children of 'app'
            }
        })
        .state('app.contacts', {
            url: '/contacts',
            templateUrl: 'app/states/contacts/contacts.html'
        })
        .state('app.profile', {
            url: '/profile',
            templateUrl: 'app/states/profile/profile.html'
        });

}
